python3 sudoku.py
