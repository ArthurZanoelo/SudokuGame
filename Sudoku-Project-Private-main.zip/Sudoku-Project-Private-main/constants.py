import pygame
pygame.init()
BACKGROUND_COLOR = (173, 219, 237) # Light blue
NUM_SQUARES = 3
LINE_COLOR = (0, 0, 0) # Black
MARGIN = 100
LINE_WIDTH = 8
SELECTED_CELL_COLOR = (255, 0, 0) # Red
BUTTON_FONT = pygame.font.SysFont(None, 20)
TEXT_COLOR = (252, 152, 3) # Orange
BUTTON_COLOR = (0, 0, 0) # Black
NUM_FONT = pygame.font.SysFont(None, 50)
